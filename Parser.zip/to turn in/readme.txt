// Steve Louis
//cop 3402 parser
//07/16/2018

-README TXT FILE

	-HOW TO RUN THE PARSER

		-Run the file name compiler.c with the name of the inputfile from the directory"a base input is given in inputLexical.txt but other input files can be used."

		-A with the in put file 3 other command line arguments can be given an they are "-l" wich printf the output if the lexical,"-a" wich prints the output of the parser
			and "-v"wich prints the output of the virtual machine.

		-The order of the command line arguments do not matter.

		-The input file is the only command line argument necessary to make the program work.